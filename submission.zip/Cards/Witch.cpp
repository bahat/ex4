//
// Created by Omer Bahat on 12/01/2023.
//

#include "Witch.h"

Witch::Witch() : BattleCard(WITCH_NAME, WITCH_FORCE, WITCH_DAMAGE, WITCH_LOOT) {}
